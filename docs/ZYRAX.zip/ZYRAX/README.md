# ZYRAX AI

Dual-agent Android assistant: **ZYRAX** (personal, female persona) and **JARVIS** (operations/research,
male persona), with separate histories, prompts, voice settings, delegation, memory, tasks, and
approval-gated operations.

Kotlin · Jetpack Compose · Material 3 · MVVM · Room · Coroutines/Flow · OkHttp. minSdk 26, targetSdk 34.

## Build status
This source was written without access to a build machine. **It has not been compiled or run yet.**
Build it with the GitHub Actions workflow below and report any errors.

## Build the APK with GitHub Actions
1. Push this project to your repository (`main` branch).
2. Open **Actions → Build Debug APK** (it also runs on every push) → wait for green.
3. Open the finished run → **Artifacts → zyrax-ai-debug-apk** → download and unzip `app-debug.apk`.
   Output path in the build: `app/build/outputs/apk/debug/app-debug.apk`.

Local build: JDK 17, Android SDK 34, Gradle 8.7 → `gradle :app:assembleDebug`
(or `gradle wrapper --gradle-version 8.7` once, then `./gradlew assembleDebug`).

## Install on Android
Copy `app-debug.apk` to the phone → open it → allow "Install unknown apps" for your file manager/browser.

## Configure AI (required)
Open **AI Providers** in the app, enter your own API key for OpenAI, Anthropic, or any OpenAI-compatible
endpoint (set Base URL + model), tap **Save**, then **Test connection**. Choose which provider each agent uses.
Keys are stored encrypted on the device (Android Keystore) and are never in the source or the repo.
Without a key the app shows "No AI provider configured" and does not fake replies.

## Avatars
See `docs/AVATAR_ASSETS.md`. Import your images from **Settings**.

## Voice
Uses Android SpeechRecognizer and TextToSpeech. Bengali/Arabic work only if the device has those voices/
recognition packs; otherwise the app tells you and falls back to the default voice. Android has no
male/female voice flag, so ZYRAX and JARVIS differ by pitch/speed plus the system voice you install.

## Delegation & security
ZYRAX can emit a delegate tag → a task is created → JARVIS runs it → the result is reported into
ZYRAX's history. JARVIS may *request* "open URL" / "web search"; each needs your Approve tap and is logged.
JARVIS has no live web access itself; it answers from the model and can open a browser for you.

## Known limits
- Not yet compiled/tested on a device (see Build status).
- File operations, notifications, Accessibility integration: not implemented.
- Photo avatars: no true blinking/lip-sync without layered assets.
- Voice recognition may need internet depending on the device.
