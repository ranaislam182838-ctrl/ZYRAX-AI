package com.zyrax.ai

import com.zyrax.ai.agent.Tags
import com.zyrax.ai.agent.normalizeTurns
import com.zyrax.ai.ai.ChatTurn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentLogicTest {
    @Test fun normalize_dropsLeadingAssistantAndMergesSameRole() {
        val out = normalizeTurns(
            listOf(
                ChatTurn("assistant", "hi"),
                ChatTurn("user", "a"),
                ChatTurn("user", "b"),
                ChatTurn("assistant", "c")
            )
        )
        assertEquals(2, out.size)
        assertEquals("user", out[0].role)
        assertTrue(out[0].content.contains("a") && out[0].content.contains("b"))
    }

    @Test fun tags_parseDelegateAndStrip() {
        val raw = "Sure, handing over.\n[[DELEGATE: find the latest Android release]]"
        assertEquals("find the latest Android release", Tags.delegate.find(raw)!!.groupValues[1])
        assertEquals("Sure, handing over.", Tags.strip(raw))
    }

    @Test fun tags_parseAction() {
        val m = Tags.action.find("[[ACTION: OPEN_URL|https://example.com]]")!!
        assertEquals("OPEN_URL", m.groupValues[1])
        assertEquals("https://example.com", m.groupValues[2])
    }
}
