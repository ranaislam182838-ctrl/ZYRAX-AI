package com.zyrax.ai.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zyrax.ai.ZyraxApp
import com.zyrax.ai.agent.AgentId
import com.zyrax.ai.ai.ChatTurn
import com.zyrax.ai.ai.ProviderFactory
import com.zyrax.ai.data.*
import com.zyrax.ai.ops.PendingAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val c = app as ZyraxApp
    val settings = c.settings
    val voice = c.voice
    private val db = c.db
    private val repo = c.repo

    val zyraxMessages = db.messages().observe(AgentId.ZYRAX.key).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val jarvisMessages = db.messages().observe(AgentId.JARVIS.key).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val tasks = db.tasks().observe().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val memories = db.memories().observe().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val logs = db.logs().observe().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val pending: StateFlow<List<PendingAction>> = c.ops.pending

    val busy = MutableStateFlow<Set<AgentId>>(emptySet())
    val message = MutableStateFlow<String?>(null)
    val avatarVersion = MutableStateFlow(0)
    val lastReply = MutableStateFlow("")

    fun messages(a: AgentId) = if (a == AgentId.ZYRAX) zyraxMessages else jarvisMessages

    fun send(agent: AgentId, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        viewModelScope.launch {
            busy.update { it + agent }
            val r = repo.send(agent, t)
            busy.update { it - agent }
            if (r.error != null) message.value = r.error
            else r.spokenText?.let {
                lastReply.value = it
                voice.speak(agent.key, it, settings.voice(agent.key, agent.defaultPitch))
            }
        }
    }

    fun listen(agent: AgentId) {
        val lang = settings.voice(agent.key, agent.defaultPitch).language
        voice.startListening(lang, onText = { send(agent, it) }, fail = { message.value = it })
    }

    fun runTask(id: Long) { viewModelScope.launch { repo.runTask(id) } }
    fun createTask(title: String, details: String, to: AgentId) {
        if (title.isBlank()) return
        viewModelScope.launch { repo.createTask(title.trim(), details.trim(), to) }
    }
    fun setTaskStatus(t: TaskEntity, status: String) {
        viewModelScope.launch { db.tasks().update(t.copy(status = status, updatedAt = System.currentTimeMillis())) }
    }
    fun deleteTask(id: Long) { viewModelScope.launch { db.tasks().delete(id) } }

    fun addMemory(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch { db.memories().insert(MemoryEntity(text = text.trim())) }
    }
    fun deleteMemory(id: Long) { viewModelScope.launch { db.memories().delete(id) } }

    fun approve(id: Long) {
        viewModelScope.launch {
            val a = pending.value.firstOrNull { it.id == id }
            val result = c.ops.approve(id)
            repo.log(a?.agent ?: "JARVIS", "ACTION_APPROVED", result)
            message.value = result
        }
    }
    fun reject(id: Long) {
        viewModelScope.launch {
            val a = pending.value.firstOrNull { it.id == id }
            c.ops.reject(id)
            repo.log(a?.agent ?: "JARVIS", "ACTION_REJECTED_BY_USER", a?.summary ?: "")
        }
    }

    fun clearHistory(a: AgentId) { viewModelScope.launch { db.messages().clear(a.key); repo.log("User", "HISTORY_CLEARED", a.displayName) } }
    fun clearMemory() { viewModelScope.launch { db.memories().clear(); repo.log("User", "MEMORY_CLEARED", "") } }
    fun clearLogs() { viewModelScope.launch { db.logs().clear() } }
    fun clearTasks() { viewModelScope.launch { db.tasks().clear(); repo.log("User", "TASKS_CLEARED", "") } }
    fun clearEverything() {
        viewModelScope.launch {
            db.messages().clearAll(); db.memories().clear(); db.tasks().clear(); db.logs().clear()
            message.value = "All local history, memory, tasks and logs cleared."
        }
    }

    /** Real connection test: sends one short request with the saved credentials. */
    fun testProvider(type: ProviderType) {
        viewModelScope.launch {
            message.value = "Testing ${type.label}…"
            message.value = try {
                val p = ProviderFactory.create(settings.providerConfig(type))
                val r = p.complete("Reply with the single word OK.", listOf(ChatTurn("user", "ping")))
                "✔ ${type.label} responded: ${r.take(60)}"
            } catch (e: Exception) { "✖ ${e.message}" }
        }
    }

    // ---- Avatars ----
    private fun avatarFile(a: AgentId) = File(File(getApplication<Application>().filesDir, "avatars").apply { mkdirs() }, "${a.key}.png")

    fun loadAvatar(a: AgentId): ImageBitmap? {
        val f = avatarFile(a)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
    }

    suspend fun loadAvatarAsync(a: AgentId): ImageBitmap? = withContext(Dispatchers.IO) { loadAvatar(a) }

    fun importAvatar(a: AgentId, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cr = getApplication<Application>().contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val bmp = cr.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: throw IllegalStateException("Could not read image")
                FileOutputStream(avatarFile(a)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                avatarVersion.update { it + 1 }
                message.value = "${a.displayName} avatar imported."
            } catch (e: Exception) {
                message.value = "Avatar import failed: ${e.message}"
            }
        }
    }

    fun removeAvatar(a: AgentId) {
        avatarFile(a).delete()
        avatarVersion.update { it + 1 }
    }

    override fun onCleared() { voice.stopListening() }
}
