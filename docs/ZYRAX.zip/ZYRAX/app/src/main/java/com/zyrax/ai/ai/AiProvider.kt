package com.zyrax.ai.ai

import com.zyrax.ai.data.ProviderConfig
import com.zyrax.ai.data.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatTurn(val role: String, val content: String) // role: "user" | "assistant"

class AiException(message: String) : Exception(message)

interface AiProvider {
    suspend fun complete(system: String, history: List<ChatTurn>): String
}

private val http: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
}
private val JSON = "application/json; charset=utf-8".toMediaType()

private suspend fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject =
    withContext(Dispatchers.IO) {
        val rb = Request.Builder().url(url).post(body.toString().toRequestBody(JSON))
        headers.forEach { (k, v) -> rb.addHeader(k, v) }
        try {
            http.newCall(rb.build()).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val msg = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw AiException("API error ${resp.code}: ${if (msg.isNullOrBlank()) text.take(300) else msg}")
                }
                JSONObject(text)
            }
        } catch (e: AiException) {
            throw e
        } catch (e: Exception) {
            throw AiException("Network error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

class OpenAiCompatibleProvider(private val cfg: ProviderConfig) : AiProvider {
    override suspend fun complete(system: String, history: List<ChatTurn>): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", cfg.model).put("messages", msgs)
        val res = post(
            cfg.baseUrl.trimEnd('/') + "/chat/completions",
            mapOf("Authorization" to "Bearer ${cfg.apiKey}", "Content-Type" to "application/json"),
            body
        )
        return res.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?.takeIf { it.isNotBlank() } ?: throw AiException("Empty response from provider")
    }
}

class AnthropicProvider(private val cfg: ProviderConfig) : AiProvider {
    override suspend fun complete(system: String, history: List<ChatTurn>): String {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", cfg.model).put("max_tokens", 1024)
            .put("system", system).put("messages", msgs)
        val res = post(
            cfg.baseUrl.trimEnd('/') + "/messages",
            mapOf("x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01", "Content-Type" to "application/json"),
            body
        )
        val content = res.optJSONArray("content") ?: throw AiException("Empty response from provider")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString().ifBlank { throw AiException("Empty response from provider") }
    }
}

object ProviderFactory {
    fun create(cfg: ProviderConfig): AiProvider {
        if (!cfg.isUsable) {
            throw AiException(
                "No AI provider configured for ${cfg.type.label}. Open Settings → AI Providers and enter an API key, base URL and model."
            )
        }
        return when (cfg.type) {
            ProviderType.ANTHROPIC -> AnthropicProvider(cfg)
            ProviderType.OPENAI, ProviderType.COMPATIBLE -> OpenAiCompatibleProvider(cfg)
        }
    }
}
