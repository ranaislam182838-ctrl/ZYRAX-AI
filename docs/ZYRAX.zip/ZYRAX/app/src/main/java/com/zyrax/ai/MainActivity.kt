package com.zyrax.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zyrax.ai.agent.AgentId
import com.zyrax.ai.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZyraxTheme { AppRoot() } }
    }
}

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    val msg by vm.message.collectAsState()
    val notice by vm.voice.notice.collectAsState()
    val pending by vm.pending.collectAsState()

    LaunchedEffect(msg) { msg?.let { snackbar.showSnackbar(it); vm.message.value = null } }
    LaunchedEffect(notice) { notice?.let { snackbar.showSnackbar(it); vm.voice.notice.value = null } }

    val items = listOf(
        NavItem("dashboard", "Home", Icons.Filled.Home),
        NavItem("zyrax", "ZYRAX", Icons.Filled.Face),
        NavItem("jarvis", "JARVIS", Icons.Filled.Terminal),
        NavItem("voice", "Voice", Icons.Filled.Mic),
        NavItem("tasks", "Tasks", Icons.Filled.CheckCircle)
    )
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val go: (String) -> Unit = { r ->
        nav.navigate(r) { popUpTo(nav.graph.findStartDestination().id); launchSingleTop = true }
    }

    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                items.forEach { i ->
                    NavigationBarItem(
                        selected = route == i.route, onClick = { go(i.route) },
                        icon = { Icon(i.icon, i.label) }, label = { Text(i.label) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = androidx.compose.ui.graphics.Color.Black, indicatorColor = Cyan)
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(pad)) {
            composable("dashboard") { DashboardScreen(vm, go) }
            composable("zyrax") { ChatScreen(vm, AgentId.ZYRAX, go) }
            composable("jarvis") { ChatScreen(vm, AgentId.JARVIS, go) }
            composable("voice") { VoiceScreen(vm) }
            composable("tasks") { TasksScreen(vm) }
            composable("history") { HistoryScreen(vm) }
            composable("memory") { MemoryScreen(vm) }
            composable("providers") { ProvidersScreen(vm) }
            composable("security") { SecurityScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
        }
    }

    pending.firstOrNull()?.let { a ->
        AlertDialog(
            onDismissRequest = { vm.reject(a.id) },
            title = { Text("${a.agent} requests permission") },
            text = { Text(a.summary + "\n\nThis will only run if you approve.") },
            confirmButton = { TextButton(onClick = { vm.approve(a.id) }) { Text("Approve") } },
            dismissButton = { TextButton(onClick = { vm.reject(a.id) }) { Text("Reject") } }
        )
    }
}
