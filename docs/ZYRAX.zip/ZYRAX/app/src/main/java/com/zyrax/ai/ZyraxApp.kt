package com.zyrax.ai

import android.app.Application
import com.zyrax.ai.agent.AgentRepository
import com.zyrax.ai.data.AppDatabase
import com.zyrax.ai.data.SettingsStore
import com.zyrax.ai.ops.OperationsManager
import com.zyrax.ai.voice.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class ZyraxApp : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val db by lazy { AppDatabase.create(this) }
    val settings by lazy { SettingsStore(this) }
    val ops by lazy { OperationsManager(this) }
    val voice by lazy { VoiceManager(this).also { it.init() } }
    val repo by lazy { AgentRepository(db, settings, ops, appScope) }
}
