package com.zyrax.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.zyrax.ai.agent.AgentId
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtTime(t: Long): String = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(t))

@Composable
fun Card2(
    modifier: Modifier = Modifier,
    border: Color = Cyan.copy(alpha = 0.25f),
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, border, RoundedCornerShape(16.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
fun AgentAvatar(
    vm: AppViewModel,
    agent: AgentId,
    modifier: Modifier = Modifier,
    listening: Boolean = false
) {
    val ver by vm.avatarVersion.collectAsState()
    val bmp by produceState<ImageBitmap?>(null, agent, ver) { value = vm.loadAvatarAsync(agent) }
    val speakingAgent by vm.voice.speakingAgent.collectAsState()
    val level by vm.voice.micLevel.collectAsState()
    val busy by vm.busy.collectAsState()
    val speaking = speakingAgent == agent.key
    val expr = when {
        agent in busy -> Expression.THINKING
        speaking -> Expression.HAPPY
        else -> Expression.NEUTRAL
    }
    AvatarView(
        agent = agent, bitmap = bmp, speaking = speaking, listening = listening, micLevel = level,
        expression = expr, showMouthOverlay = vm.settings.flag("mouth_overlay_${agent.key}", false),
        modifier = modifier
    )
}
