package com.zyrax.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.zyrax.ai.data.VoiceConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

val SUPPORTED_LANGUAGES = listOf(
    "en-US" to "English",
    "bn-BD" to "বাংলা (Bengali)",
    "ar-SA" to "العربية (Arabic)",
    "hi-IN" to "हिन्दी (Hindi)",
    "ur-PK" to "اردو (Urdu)"
)

/**
 * Wraps Android TextToSpeech and SpeechRecognizer. Voices come from the device: if a language
 * pack is missing we say so and fall back to the device default instead of pretending.
 * Android exposes no reliable male/female voice flag, so the agents differ by pitch and the
 * voice the user picks in system TTS settings.
 */
class VoiceManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    val speakingAgent = MutableStateFlow<String?>(null)
    val listening = MutableStateFlow(false)
    val micLevel = MutableStateFlow(0f)
    val notice = MutableStateFlow<String?>(null)

    private var recognizer: SpeechRecognizer? = null

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (!ttsReady) notice.value = "Text-to-speech engine is not available on this device."
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speakingAgent.value = utteranceId?.substringBefore(':') }
            override fun onDone(utteranceId: String?) { speakingAgent.value = null }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speakingAgent.value = null }
        })
    }

    fun speak(agentKey: String, text: String, cfg: VoiceConfig) {
        if (!cfg.enabled || text.isBlank()) return
        val engine = tts
        if (engine == null || !ttsReady) { notice.value = "Voice not ready yet."; return }
        val locale = Locale.forLanguageTag(cfg.language)
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            notice.value = "${locale.displayName} voice is not installed on this device. Using the default voice. " +
                "Install it in Android Settings → Text-to-speech."
            engine.setLanguage(Locale.getDefault())
        }
        engine.setPitch(cfg.pitch)
        engine.setSpeechRate(cfg.rate)
        engine.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "$agentKey:${System.nanoTime()}")
    }

    fun stopSpeaking() { tts?.stop(); speakingAgent.value = null }

    fun isRecognitionAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /** Must be called on the main thread, after RECORD_AUDIO has been granted. */
    fun startListening(languageTag: String, onText: (String) -> Unit, fail: (String) -> Unit) {
        if (!isRecognitionAvailable()) { fail("Speech recognition is not available on this device."); return }
        stopListening()
        val sr = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening.value = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { micLevel.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening.value = false }
            override fun onError(error: Int) {
                listening.value = false; micLevel.value = 0f
                fail(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Try again."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs a network connection for this language."
                    SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "This language is not supported by the device's speech recognizer."
                    else -> "Speech recognition error ($error)."
                })
            }
            override fun onResults(results: Bundle?) {
                listening.value = false; micLevel.value = 0f
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) fail("I didn't catch that. Try again.") else onText(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        sr.startListening(intent)
    }

    fun stopListening() {
        recognizer?.runCatching { stopListening(); destroy() }
        recognizer = null
        listening.value = false
        micLevel.value = 0f
    }

    fun shutdown() { stopListening(); tts?.shutdown(); tts = null; ttsReady = false }
}
