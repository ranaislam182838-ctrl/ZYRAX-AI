package com.zyrax.ai.agent

import com.zyrax.ai.ai.AiException
import com.zyrax.ai.ai.ChatTurn
import com.zyrax.ai.ai.ProviderFactory
import com.zyrax.ai.data.*
import com.zyrax.ai.ops.OperationsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Makes a history valid for provider APIs: starts with user, roles alternate. */
fun normalizeTurns(raw: List<ChatTurn>): List<ChatTurn> {
    val out = ArrayList<ChatTurn>()
    for (t in raw) {
        if (t.content.isBlank()) continue
        if (out.isNotEmpty() && out.last().role == t.role) {
            out[out.size - 1] = ChatTurn(t.role, out.last().content + "\n\n" + t.content)
        } else out.add(t)
    }
    while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
    return out
}

class ChatResult(val spokenText: String?, val error: String?)

class AgentRepository(
    private val db: AppDatabase,
    private val settings: SettingsStore,
    private val ops: OperationsManager,
    private val scope: CoroutineScope
) {
    suspend fun log(agent: String, action: String, detail: String) {
        db.logs().insert(LogEntity(agent = agent, action = action, detail = detail.take(400)))
    }

    private suspend fun systemPrompt(agent: AgentId): String {
        val mem = db.memories().all().map { it.text }
        val custom = settings.customPrompt(agent.key)
        return if (agent == AgentId.ZYRAX) Prompts.zyrax(mem, custom, settings.jarvisAutoDelegate())
        else Prompts.jarvis(mem, custom)
    }

    private suspend fun ask(agent: AgentId): String {
        val provider = ProviderFactory.create(settings.configFor(agent.key))
        val turns = db.messages().recent(agent.key, 20).reversed().map { ChatTurn(it.role, it.content) }
        return provider.complete(systemPrompt(agent), normalizeTurns(turns))
    }

    suspend fun send(agent: AgentId, userText: String): ChatResult {
        db.messages().insert(MessageEntity(agent = agent.key, role = "user", content = userText))
        return try {
            val raw = ask(agent)
            val clean = Tags.strip(raw)
            db.messages().insert(MessageEntity(agent = agent.key, role = "assistant", content = clean.ifBlank { "…" }))
            handleTags(agent, raw, userText)
            ChatResult(clean, null)
        } catch (e: AiException) {
            ChatResult(null, e.message)
        } catch (e: Exception) {
            ChatResult(null, "Unexpected error: ${e.message}")
        }
    }

    private suspend fun handleTags(agent: AgentId, raw: String, userText: String) {
        Tags.remember.findAll(raw).forEach {
            val t = it.groupValues[1].trim()
            if (t.isNotEmpty()) {
                db.memories().insert(MemoryEntity(text = t))
                log(agent.displayName, "MEMORY_SAVED", t)
            }
        }
        if (agent == AgentId.ZYRAX && settings.jarvisAutoDelegate()) {
            Tags.delegate.findAll(raw).forEach {
                val desc = it.groupValues[1].trim()
                if (desc.isNotEmpty()) delegate(desc, userText)
            }
        }
        if (agent == AgentId.JARVIS) proposeActions(raw)
    }

    private suspend fun proposeActions(raw: String) {
        Tags.action.findAll(raw).forEach {
            val a = ops.propose(AgentId.JARVIS.displayName, it.groupValues[1], it.groupValues[2])
            if (a != null) log("JARVIS", "ACTION_PROPOSED", a.summary)
            else log("JARVIS", "ACTION_REJECTED", "Invalid or unsafe request: ${it.value.take(120)}")
        }
    }

    /** ZYRAX → JARVIS delegation. Creates a task and runs it in the background. */
    suspend fun delegate(description: String, context: String = "") {
        val id = db.tasks().insert(
            TaskEntity(title = description.take(60), details = description,
                fromAgent = AgentId.ZYRAX.displayName, toAgent = AgentId.JARVIS.displayName, status = "PENDING")
        )
        log("ZYRAX", "TASK_DELEGATED", "#$id → JARVIS: $description")
        scope.launch { runTask(id) }
    }

    /** Executes a task by asking JARVIS, then reports the result back into ZYRAX's history. */
    suspend fun runTask(id: Long) {
        val t = db.tasks().get(id) ?: return
        if (t.status == "RUNNING") return
        db.tasks().update(t.copy(status = "RUNNING", updatedAt = System.currentTimeMillis()))
        log("JARVIS", "TASK_STARTED", "#$id ${t.title}")
        db.messages().insert(MessageEntity(agent = "jarvis", role = "user", content = "[Task #$id from ${t.fromAgent}] ${t.details}"))
        try {
            val raw = ask(AgentId.JARVIS)
            val clean = Tags.strip(raw)
            db.messages().insert(MessageEntity(agent = "jarvis", role = "assistant", content = clean.ifBlank { "…" }))
            proposeActions(raw)
            db.tasks().update(t.copy(status = "DONE", result = clean, updatedAt = System.currentTimeMillis()))
            log("JARVIS", "TASK_DONE", "#$id")
            db.messages().insert(MessageEntity(agent = "zyrax", role = "user",
                content = "[Report from JARVIS on task #$id: ${t.title}]\n$clean"))
        } catch (e: Exception) {
            val msg = e.message ?: "unknown error"
            db.tasks().update(t.copy(status = "FAILED", result = msg, updatedAt = System.currentTimeMillis()))
            log("JARVIS", "TASK_FAILED", "#$id $msg")
        }
    }

    suspend fun createTask(title: String, details: String, to: AgentId) {
        db.tasks().insert(TaskEntity(title = title, details = details.ifBlank { title },
            fromAgent = "User", toAgent = to.displayName, status = "PENDING"))
        log("User", "TASK_CREATED", "$title → ${to.displayName}")
    }
}
