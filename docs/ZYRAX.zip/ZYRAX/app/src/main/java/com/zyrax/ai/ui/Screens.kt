@file:OptIn(ExperimentalMaterial3Api::class)

package com.zyrax.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.zyrax.ai.agent.AgentId
import com.zyrax.ai.data.ProviderConfig
import com.zyrax.ai.data.ProviderType
import com.zyrax.ai.data.TaskEntity
import com.zyrax.ai.voice.SUPPORTED_LANGUAGES

// ───────────────────────── Dashboard ─────────────────────────
@Composable
fun DashboardScreen(vm: AppViewModel, nav: (String) -> Unit) {
    val tasks by vm.tasks.collectAsState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ZYRAX AI", style = MaterialTheme.typography.headlineMedium, color = Cyan, fontWeight = FontWeight.Bold)
        Text("Dual-agent personal assistant", color = TextDim)
        AgentCard(vm, AgentId.ZYRAX, "Personal assistant · conversation · planning") { nav("zyrax") }
        AgentCard(vm, AgentId.JARVIS, "Operations · research · browser assistance") { nav("jarvis") }
        Card2 {
            Text("Tasks", fontWeight = FontWeight.SemiBold)
            Text(
                "Pending ${tasks.count { it.status == "PENDING" }} · Running ${tasks.count { it.status == "RUNNING" }} · " +
                    "Done ${tasks.count { it.status == "DONE" }} · Failed ${tasks.count { it.status == "FAILED" }}",
                color = TextDim
            )
        }
        val tiles = listOf(
            Triple("Voice", Icons.Filled.Mic, "voice"), Triple("Tasks", Icons.Filled.CheckCircle, "tasks"),
            Triple("History", Icons.Filled.History, "history"), Triple("Memory", Icons.Filled.Memory, "memory"),
            Triple("AI Providers", Icons.Filled.Cloud, "providers"), Triple("Security", Icons.Filled.Security, "security"),
            Triple("Settings", Icons.Filled.Settings, "settings")
        )
        tiles.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (label, icon, route) -> Tile(label, icon, Modifier.weight(1f)) { nav(route) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun AgentCard(vm: AppViewModel, agent: AgentId, role: String, onClick: () -> Unit) {
    val cfg = vm.settings.configFor(agent.key)
    Card2(Modifier.fillMaxWidth().clickable(onClick = onClick), border = agentColor(agent).copy(alpha = 0.6f)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AgentAvatar(vm, agent, Modifier.size(88.dp))
            Column {
                Text(agent.displayName, style = MaterialTheme.typography.titleLarge, color = agentColor(agent), fontWeight = FontWeight.Bold)
                Text(role, color = TextDim, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(4.dp))
                if (cfg.isUsable) Text("Provider: ${cfg.type.label} · ${cfg.model}", color = Ok, style = MaterialTheme.typography.bodySmall)
                else Text("⚠ No AI provider configured", color = Danger, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Tile(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card2(modifier.clickable(onClick = onClick)) {
        Icon(icon, null, tint = Cyan)
        Spacer(Modifier.height(6.dp))
        Text(label, fontWeight = FontWeight.Medium)
    }
}

// ───────────────────────── Chat ─────────────────────────
@Composable
fun ChatScreen(vm: AppViewModel, agent: AgentId, nav: (String) -> Unit) {
    val msgs by vm.messages(agent).collectAsState()
    val busy by vm.busy.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val color = agentColor(agent)
    LaunchedEffect(msgs.size, busy) {
        val n = msgs.size + if (agent in busy) 1 else 0
        if (n > 0) listState.animateScrollToItem(n - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AgentAvatar(vm, agent, Modifier.size(96.dp))
            Column(Modifier.weight(1f)) {
                Text(agent.displayName, style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
                Text(if (agent == AgentId.ZYRAX) "Personal assistant" else "Operations & research", color = TextDim)
                val cfg = vm.settings.configFor(agent.key)
                if (!cfg.isUsable) {
                    Text("No provider configured — tap to set up", color = Danger,
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.clickable { nav("providers") })
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs, key = { it.id }) { m ->
                val mine = m.role == "user" && !m.content.startsWith("[")
                val report = m.content.startsWith("[Report from") || m.content.startsWith("[Task #")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 300.dp)
                            .background(if (mine) PanelHi else Panel, RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        if (report) Text("↔ Delegation", color = Blue, style = MaterialTheme.typography.labelSmall)
                        Text(m.content)
                        Text(fmtTime(m.timestamp), color = TextDim, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (agent in busy) item { Text("${agent.displayName} is thinking…", color = color) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message ${agent.displayName}…") }, maxLines = 4
            )
            IconButton(onClick = { vm.voice.stopSpeaking() }) { Icon(Icons.Filled.Stop, "Stop speaking", tint = TextDim) }
            IconButton(onClick = { vm.send(agent, input); input = "" }, enabled = input.isNotBlank() && agent !in busy) {
                Icon(Icons.Filled.Send, "Send", tint = color)
            }
        }
    }
}

// ───────────────────────── Voice ─────────────────────────
@Composable
fun VoiceScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var agent by remember { mutableStateOf(AgentId.ZYRAX) }
    val listening by vm.voice.listening.collectAsState()
    val speaking by vm.voice.speakingAgent.collectAsState()
    val busy by vm.busy.collectAsState()
    val last by vm.lastReply.collectAsState()
    val cfg = vm.settings.voice(agent.key, agent.defaultPitch)

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.listen(agent) else vm.message.value = "Microphone permission denied. Voice input is disabled until you allow it."
    }
    fun onMic() {
        if (listening) { vm.voice.stopListening(); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.listen(agent)
        else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AgentId.values().forEach { a ->
                FilterChip(selected = agent == a, onClick = { agent = a }, label = { Text(a.displayName) })
            }
        }
        AgentAvatar(vm, agent, Modifier.size(260.dp), listening = listening)
        Text(
            when {
                listening -> "Listening…"
                agent in busy -> "${agent.displayName} is thinking…"
                speaking == agent.key -> "${agent.displayName} is speaking…"
                else -> "Tap the microphone and speak"
            }, color = agentColor(agent)
        )
        Text("Language: ${SUPPORTED_LANGUAGES.firstOrNull { it.first == cfg.language }?.second ?: cfg.language}", color = TextDim)
        FloatingActionButton(onClick = { onMic() }, containerColor = agentColor(agent), contentColor = Color.Black) {
            Icon(if (listening) Icons.Filled.Stop else Icons.Filled.Mic, "Microphone")
        }
        if (!vm.voice.isRecognitionAvailable())
            Text("Speech recognition is not available on this device.", color = Danger)
        if (last.isNotBlank()) Card2(Modifier.fillMaxWidth()) { Text("Last reply", color = TextDim); Text(last) }
        TextButton(onClick = { vm.voice.stopSpeaking() }) { Text("Stop speaking") }
    }
}

// ───────────────────────── Tasks ─────────────────────────
@Composable
fun TasksScreen(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        if (tasks.isEmpty()) Text("No tasks yet. Create one, or ask ZYRAX to delegate research to JARVIS.", color = TextDim, modifier = Modifier.padding(24.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tasks, key = { it.id }) { t -> TaskRow(vm, t) }
        }
        FloatingActionButton(onClick = { showAdd = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = Cyan, contentColor = Color.Black) { Icon(Icons.Filled.Add, "Add task") }
    }
    if (showAdd) AddTaskDialog(onDismiss = { showAdd = false }) { title, details, to -> vm.createTask(title, details, to); showAdd = false }
}

@Composable
private fun TaskRow(vm: AppViewModel, t: TaskEntity) {
    val statusColor = when (t.status) { "DONE" -> Ok; "FAILED" -> Danger; "RUNNING" -> Cyan; else -> TextDim }
    Card2(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(t.status, color = statusColor, style = MaterialTheme.typography.labelMedium)
        }
        Text("${t.fromAgent} → ${t.toAgent} · ${fmtTime(t.createdAt)}", color = TextDim, style = MaterialTheme.typography.bodySmall)
        if (t.details != t.title) Text(t.details, style = MaterialTheme.typography.bodySmall)
        if (t.result.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text("Result: ${t.result}", color = TextMain, style = MaterialTheme.typography.bodySmall) }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (t.toAgent == AgentId.JARVIS.displayName && (t.status == "PENDING" || t.status == "FAILED"))
                TextButton(onClick = { vm.runTask(t.id) }) { Text("Run with JARVIS") }
            if (t.status != "DONE" && t.status != "RUNNING")
                TextButton(onClick = { vm.setTaskStatus(t, "DONE") }) { Text("Mark done") }
            TextButton(onClick = { vm.deleteTask(t.id) }) { Text("Delete", color = Danger) }
        }
    }
}

@Composable
private fun AddTaskDialog(onDismiss: () -> Unit, onCreate: (String, String, AgentId) -> Unit) {
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var to by remember { mutableStateOf(AgentId.JARVIS) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(details, { details = it }, label = { Text("Details (optional)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AgentId.values().forEach { a -> FilterChip(selected = to == a, onClick = { to = a }, label = { Text("For ${a.displayName}") }) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(title, details, to) }, enabled = title.isNotBlank()) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ───────────────────────── History & Activity log ─────────────────────────
@Composable
fun HistoryScreen(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val z by vm.zyraxMessages.collectAsState()
    val j by vm.jarvisMessages.collectAsState()
    val logs by vm.logs.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = Bg, contentColor = Cyan) {
            listOf("ZYRAX", "JARVIS", "Activity log").forEachIndexed { i, s -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) }) }
        }
        Row(Modifier.padding(horizontal = 8.dp)) {
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                when (tab) { 0 -> vm.clearHistory(AgentId.ZYRAX); 1 -> vm.clearHistory(AgentId.JARVIS); else -> vm.clearLogs() }
            }) { Text("Clear this list", color = Danger) }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab < 2) {
                val list = if (tab == 0) z else j
                items(list.asReversed(), key = { it.id }) { m ->
                    Card2(Modifier.fillMaxWidth()) {
                        Text("${if (m.role == "user") "You / system" else AgentId.fromKey(m.agent).displayName} · ${fmtTime(m.timestamp)}", color = TextDim, style = MaterialTheme.typography.labelSmall)
                        Text(m.content)
                    }
                }
            } else {
                items(logs, key = { it.id }) { l ->
                    Card2(Modifier.fillMaxWidth()) {
                        Text("${l.agent} · ${l.action} · ${fmtTime(l.timestamp)}", color = Cyan, style = MaterialTheme.typography.labelSmall)
                        Text(l.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Memory & personalization ─────────────────────────
@Composable
fun MemoryScreen(vm: AppViewModel) {
    val mem by vm.memories.collectAsState()
    var newFact by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(vm.settings.jarvisAutoDelegate()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Memory & personalization", style = MaterialTheme.typography.titleLarge, color = Cyan)
        Text("Facts here are sent to both agents with every request. Do not store passwords or secrets.", color = TextDim)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(newFact, { newFact = it }, Modifier.weight(1f), label = { Text("Add a fact or preference") })
            IconButton(onClick = { vm.addMemory(newFact); newFact = "" }) { Icon(Icons.Filled.Add, "Add", tint = Cyan) }
        }
        mem.forEach { m ->
            Card2(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteMemory(m.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = Danger) }
                }
            }
        }
        if (mem.isNotEmpty()) TextButton(onClick = { vm.clearMemory() }) { Text("Clear all memory", color = Danger) }
        HorizontalDivider()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Let ZYRAX delegate tasks to JARVIS automatically", Modifier.weight(1f))
            Switch(checked = auto, onCheckedChange = { auto = it; vm.settings.setJarvisAutoDelegate(it) })
        }
        AgentId.values().forEach { a ->
            var p by remember { mutableStateOf(vm.settings.customPrompt(a.key)) }
            OutlinedTextField(
                p, { p = it; vm.settings.setCustomPrompt(a.key, it) }, Modifier.fillMaxWidth(),
                label = { Text("Extra instructions for ${a.displayName}") }
            )
        }
    }
}

// ───────────────────────── AI providers ─────────────────────────
@Composable
fun ProvidersScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI providers", style = MaterialTheme.typography.titleLarge, color = Cyan)
        Text("API keys are stored encrypted on this device only (Android Keystore). They are never in the source code or GitHub.", color = TextDim)
        AgentId.values().forEach { a ->
            var sel by remember { mutableStateOf(vm.settings.activeProvider(a.key)) }
            Card2(Modifier.fillMaxWidth(), border = agentColor(a).copy(alpha = 0.5f)) {
                Text("${a.displayName} uses:", color = agentColor(a), fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProviderType.values().forEach { t ->
                        FilterChip(selected = sel == t, onClick = { sel = t; vm.settings.setActiveProvider(a.key, t) }, label = { Text(t.label) })
                    }
                }
            }
        }
        ProviderType.values().forEach { ProviderForm(vm, it) }
    }
}

@Composable
private fun ProviderForm(vm: AppViewModel, type: ProviderType) {
    val saved = vm.settings.providerConfig(type)
    var key by remember { mutableStateOf("") }
    var url by remember { mutableStateOf(saved.baseUrl) }
    var model by remember { mutableStateOf(saved.model) }
    var hasKey by remember { mutableStateOf(saved.apiKey.isNotBlank()) }
    Card2(Modifier.fillMaxWidth()) {
        Text(type.label, fontWeight = FontWeight.SemiBold)
        Text(if (hasKey) "API key saved" else "No API key saved", color = if (hasKey) Ok else Danger, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text(if (hasKey) "New API key (leave empty to keep)" else "API key") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions.Default)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") }, singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        Row {
            TextButton(onClick = {
                vm.settings.saveProvider(ProviderConfig(type, key.ifBlank { saved.apiKey }.ifBlank { vm.settings.providerConfig(type).apiKey }, url, model))
                hasKey = vm.settings.providerConfig(type).apiKey.isNotBlank(); key = ""
                vm.message.value = "${type.label} settings saved."
            }) { Text("Save") }
            TextButton(onClick = { vm.testProvider(type) }) { Text("Test connection") }
        }
    }
}

// ───────────────────────── Permissions & security ─────────────────────────
@Composable
fun SecurityScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val pending by vm.pending.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Permissions & security", style = MaterialTheme.typography.titleLarge, color = Cyan)
        Card2(Modifier.fillMaxWidth()) {
            Text("Microphone", fontWeight = FontWeight.SemiBold)
            Text(if (micOk) "Granted" else "Not granted — requested when you first use voice input", color = if (micOk) Ok else TextDim)
            TextButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Open Android app settings") }
        }
        Card2(Modifier.fillMaxWidth()) {
            Text("What JARVIS can do", fontWeight = FontWeight.SemiBold)
            Text("• Open a web page in your browser (after your approval)\n• Run a web search in your browser (after your approval)\n• Report task results to ZYRAX", color = TextDim)
            Spacer(Modifier.height(6.dp))
            Text("Every action shows an Approve / Reject dialog and is written to the activity log. JARVIS cannot read files, passwords, SMS, contacts or other apps, and the app does not use Accessibility services.", color = TextDim)
        }
        Card2(Modifier.fillMaxWidth()) {
            Text("Pending approvals: ${pending.size}", fontWeight = FontWeight.SemiBold)
            pending.forEach { Text("• ${it.summary}", color = TextDim) }
        }
        Card2(Modifier.fillMaxWidth()) {
            Text("Data & keys", fontWeight = FontWeight.SemiBold)
            Text("Conversations, memory, tasks and logs stay in a local database on this phone. Only the text of your messages, your saved facts and recent history are sent to the AI provider you configure.", color = TextDim)
        }
    }
}

// ───────────────────────── App settings (voice, avatar, data) ─────────────────────────
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var target by remember { mutableStateOf(AgentId.ZYRAX) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { vm.importAvatar(target, it) } }
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge, color = Cyan)
        AgentId.values().forEach { a ->
            var cfg by remember { mutableStateOf(vm.settings.voice(a.key, a.defaultPitch)) }
            var overlay by remember { mutableStateOf(vm.settings.flag("mouth_overlay_${a.key}", false)) }
            fun update(n: com.zyrax.ai.data.VoiceConfig) { cfg = n; vm.settings.saveVoice(a.key, n) }
            Card2(Modifier.fillMaxWidth(), border = agentColor(a).copy(alpha = 0.5f)) {
                Text(a.displayName, color = agentColor(a), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak replies aloud", Modifier.weight(1f))
                    Switch(checked = cfg.enabled, onCheckedChange = { update(cfg.copy(enabled = it)) })
                }
                Text("Voice language", color = TextDim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SUPPORTED_LANGUAGES.forEach { (tag, name) ->
                        FilterChip(selected = cfg.language == tag, onClick = { update(cfg.copy(language = tag)) }, label = { Text(name) })
                    }
                }
                Text("Pitch ${"%.2f".format(cfg.pitch)}", color = TextDim)
                Slider(cfg.pitch, { cfg = cfg.copy(pitch = it) }, valueRange = 0.5f..2f, onValueChangeFinished = { update(cfg) })
                Text("Speed ${"%.2f".format(cfg.rate)}", color = TextDim)
                Slider(cfg.rate, { cfg = cfg.copy(rate = it) }, valueRange = 0.5f..2f, onValueChangeFinished = { update(cfg) })
                TextButton(onClick = {
                    val sample = when (cfg.language) {
                        "bn-BD" -> "হ্যালো, আমি ${a.displayName}।"
                        "ar-SA" -> "مرحبا، أنا ${a.displayName}."
                        else -> "Hello, I am ${a.displayName}."
                    }
                    vm.voice.speak(a.key, sample, cfg.copy(enabled = true))
                }) { Text("Test voice") }
                HorizontalDivider()
                Text("Avatar", color = TextDim)
                Row {
                    TextButton(onClick = { target = a; picker.launch("image/*") }) { Text("Import image") }
                    TextButton(onClick = { vm.removeAvatar(a) }) { Text("Use built-in face") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mouth overlay on imported image", Modifier.weight(1f))
                    Switch(checked = overlay, onCheckedChange = { overlay = it; vm.settings.setFlag("mouth_overlay_${a.key}", it) })
                }
            }
        }
        Card2(Modifier.fillMaxWidth(), border = Danger.copy(alpha = 0.5f)) {
            Text("Danger zone", color = Danger, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { confirmClear = true }) { Text("Clear all history, memory, tasks and logs", color = Danger) }
        }
        Text("ZYRAX AI 1.0.0", color = TextDim, style = MaterialTheme.typography.bodySmall)
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear everything?") },
        text = { Text("This permanently deletes all conversations, memory, tasks and the activity log on this device. API keys are kept.") },
        confirmButton = { TextButton(onClick = { vm.clearEverything(); confirmClear = false }) { Text("Delete", color = Danger) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
    )
}
