package com.zyrax.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class ProviderType(val label: String, val defaultBaseUrl: String, val defaultModel: String) {
    OPENAI("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
    ANTHROPIC("Anthropic Claude", "https://api.anthropic.com/v1", "claude-sonnet-4-5"),
    COMPATIBLE("OpenAI-compatible (custom)", "", "")
}

data class ProviderConfig(
    val type: ProviderType,
    val apiKey: String,
    val baseUrl: String,
    val model: String
) {
    val isUsable: Boolean get() = apiKey.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()
}

data class VoiceConfig(val language: String, val pitch: Float, val rate: Float, val enabled: Boolean)

/** API keys live in EncryptedSharedPreferences (Android Keystore backed). Never in source code. */
class SettingsStore(context: Context) {
    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "zyrax_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private val prefs: SharedPreferences = context.getSharedPreferences("zyrax_prefs", Context.MODE_PRIVATE)

    fun activeProvider(agent: String): ProviderType =
        runCatching { ProviderType.valueOf(prefs.getString("provider_$agent", null) ?: "") }
            .getOrDefault(ProviderType.OPENAI)

    fun setActiveProvider(agent: String, t: ProviderType) {
        prefs.edit().putString("provider_$agent", t.name).apply()
    }

    fun providerConfig(type: ProviderType): ProviderConfig = ProviderConfig(
        type,
        secure.getString("key_${type.name}", "") ?: "",
        prefs.getString("url_${type.name}", type.defaultBaseUrl) ?: type.defaultBaseUrl,
        prefs.getString("model_${type.name}", type.defaultModel) ?: type.defaultModel
    )

    fun saveProvider(c: ProviderConfig) {
        secure.edit().putString("key_${c.type.name}", c.apiKey.trim()).apply()
        prefs.edit().putString("url_${c.type.name}", c.baseUrl.trim()).putString("model_${c.type.name}", c.model.trim()).apply()
    }

    fun configFor(agent: String): ProviderConfig = providerConfig(activeProvider(agent))

    fun voice(agent: String, defaultPitch: Float): VoiceConfig = VoiceConfig(
        prefs.getString("vlang_$agent", "en-US") ?: "en-US",
        prefs.getFloat("vpitch_$agent", defaultPitch),
        prefs.getFloat("vrate_$agent", 1.0f),
        prefs.getBoolean("vspeak_$agent", true)
    )

    fun saveVoice(agent: String, v: VoiceConfig) {
        prefs.edit().putString("vlang_$agent", v.language).putFloat("vpitch_$agent", v.pitch)
            .putFloat("vrate_$agent", v.rate).putBoolean("vspeak_$agent", v.enabled).apply()
    }

    /** Optional extra instruction the user wants appended to an agent's system prompt. */
    fun customPrompt(agent: String): String = prefs.getString("prompt_$agent", "") ?: ""
    fun setCustomPrompt(agent: String, s: String) { prefs.edit().putString("prompt_$agent", s).apply() }

    fun jarvisAutoDelegate(): Boolean = prefs.getBoolean("auto_delegate", true)
    fun setJarvisAutoDelegate(b: Boolean) { prefs.edit().putBoolean("auto_delegate", b).apply() }

    fun flag(key: String, default: Boolean): Boolean = prefs.getBoolean(key, default)
    fun setFlag(key: String, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }
}
