package com.zyrax.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.zyrax.ai.agent.AgentId
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.random.Random

enum class Expression { NEUTRAL, HAPPY, THINKING, SURPRISED }

/**
 * 2D avatar framework.
 *  - Always active (any image): idle breathing, head sway/bob, glow ring, talking pulse, listening pulse.
 *  - Built-in vector face (no image imported): eye blinking, eye movement, expressions, lip-sync mouth.
 *  - Imported photo: optional mouth overlay. True blinking / eye movement on a photo needs layered assets
 *    (see docs/AVATAR_ASSETS.md).
 */
@Composable
fun AvatarView(
    agent: AgentId,
    bitmap: ImageBitmap?,
    speaking: Boolean,
    listening: Boolean,
    micLevel: Float,
    expression: Expression,
    showMouthOverlay: Boolean,
    modifier: Modifier = Modifier
) {
    val color = agentColor(agent)
    val idle = rememberInfiniteTransition(label = "idle")
    val breath by idle.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breath")
    val sway by idle.animateFloat(-1f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Reverse), label = "sway")
    val glow by idle.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "glow")

    val blink = remember { Animatable(0f) }
    val gazeX = remember { Animatable(0f) }
    val gazeY = remember { Animatable(0f) }
    val mouth = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2200, 5200))
            blink.animateTo(1f, tween(70))
            blink.animateTo(0f, tween(110))
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(900, 2600))
            launch { gazeX.animateTo(Random.nextFloat() * 2f - 1f, tween(260)) }
            gazeY.animateTo(Random.nextFloat() * 1.2f - 0.6f, tween(260))
        }
    }
    LaunchedEffect(speaking) {
        if (speaking) {
            while (true) mouth.animateTo(Random.nextFloat() * 0.8f + 0.2f, tween(100))
        } else {
            mouth.animateTo(0f, tween(120))
        }
    }

    Canvas(modifier) {
        val side = size.minDimension
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = side / 2f * 0.94f
        val active = speaking || listening
        val pulse = if (listening) micLevel else mouth.value
        val ringAlpha = if (active) glow else 0.28f

        drawCircle(color.copy(alpha = ringAlpha * 0.22f), radius = r * (1.0f + 0.05f * pulse), center = c)
        drawCircle(color.copy(alpha = ringAlpha), radius = r, center = c, style = Stroke(width = 3.dp.toPx()))

        val pivot = Offset(c.x, c.y + r)
        rotate(degrees = sway * 2f, pivot = pivot) {
            translate(left = sway * side * 0.008f, top = breath * -side * 0.006f) {
                scale(scale = 1f + 0.015f * breath + 0.012f * mouth.value, pivot = pivot) {
                    val inner = r * 0.9f
                    if (bitmap != null) {
                        val clip = Path().apply { addOval(Rect(c, inner)) }
                        clipPath(clip) {
                            val sq = min(bitmap.width, bitmap.height)
                            val sx = (bitmap.width - sq) / 2
                            val sy = ((bitmap.height - sq) * 0.12f).toInt()
                            val d = (inner * 2f).toInt()
                            drawImage(
                                image = bitmap,
                                srcOffset = IntOffset(sx, sy), srcSize = IntSize(sq, sq),
                                dstOffset = IntOffset((c.x - inner).toInt(), (c.y - inner).toInt()),
                                dstSize = IntSize(d, d)
                            )
                        }
                        if (showMouthOverlay && mouth.value > 0.05f) {
                            val mw = inner * 0.32f
                            val mh = inner * 0.12f * mouth.value
                            drawOval(Color(0xCC12060A), topLeft = Offset(c.x - mw / 2, c.y + inner * 0.42f), size = Size(mw, mh))
                        }
                    } else {
                        drawBuiltInFace(agent, color, inner, c, blink.value, gazeX.value, gazeY.value, mouth.value, expression)
                    }
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBuiltInFace(
    agent: AgentId, color: Color, r: Float, c: Offset,
    blink: Float, gx: Float, gy: Float, mouth: Float, expr: Expression
) {
    val s = r * 2f
    val stroke = 3.dp.toPx()
    // head
    if (agent == AgentId.ZYRAX) {
        drawCircle(PanelHi, radius = r, center = c)
        drawCircle(color.copy(alpha = 0.6f), radius = r, center = c, style = Stroke(stroke))
    } else {
        val tl = Offset(c.x - r * 0.86f, c.y - r)
        val sz = Size(r * 1.72f, r * 2f)
        drawRoundRect(PanelHi, tl, sz, CornerRadius(r * 0.35f))
        drawRoundRect(color.copy(alpha = 0.6f), tl, sz, CornerRadius(r * 0.35f), style = Stroke(stroke))
    }
    // eyes
    val eyeY = c.y - s * 0.08f
    for (side in listOf(-1f, 1f)) {
        val ex = c.x + side * s * 0.2f
        val open = 1f - blink * 0.95f
        val ew = s * 0.18f
        val eh = s * 0.12f * open + 1f
        drawOval(color.copy(alpha = 0.18f), Offset(ex - ew / 2, eyeY - eh / 2), Size(ew, eh))
        if (blink < 0.7f) {
            drawCircle(color, radius = s * 0.035f * open + 1f,
                center = Offset(ex + gx * s * 0.04f, eyeY + gy * s * 0.025f))
        } else {
            drawLine(color, Offset(ex - ew / 2, eyeY), Offset(ex + ew / 2, eyeY), stroke, StrokeCap.Round)
        }
        // brows
        val raise = when (expr) {
            Expression.SURPRISED -> 0.07f
            Expression.HAPPY -> 0.035f
            Expression.THINKING -> if (side < 0) 0.065f else 0.01f
            Expression.NEUTRAL -> 0.02f
        }
        val by = eyeY - s * (0.09f + raise)
        drawLine(color.copy(alpha = 0.8f), Offset(ex - ew / 2, by), Offset(ex + ew / 2, by - if (expr == Expression.THINKING && side > 0) s * 0.015f else 0f), stroke, StrokeCap.Round)
    }
    // mouth
    val my = c.y + s * 0.22f
    val mw = s * 0.22f
    if (mouth > 0.05f || expr == Expression.SURPRISED) {
        val h = s * (0.02f + 0.1f * maxOf(mouth, if (expr == Expression.SURPRISED) 0.4f else 0f))
        drawOval(color.copy(alpha = 0.85f), Offset(c.x - mw / 2, my - h / 2), Size(mw, h))
    } else {
        val curve = when (expr) {
            Expression.HAPPY -> s * 0.05f
            Expression.THINKING -> -s * 0.01f
            else -> s * 0.015f
        }
        val p = Path().apply {
            moveTo(c.x - mw / 2, my)
            quadraticBezierTo(c.x, my + curve * 2f, c.x + mw / 2, my)
        }
        drawPath(p, color, style = Stroke(stroke, cap = StrokeCap.Round))
    }
}
