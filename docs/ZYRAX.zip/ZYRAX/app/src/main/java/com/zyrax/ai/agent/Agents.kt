package com.zyrax.ai.agent

enum class AgentId(val key: String, val displayName: String, val defaultPitch: Float) {
    ZYRAX("zyrax", "ZYRAX", 1.15f),
    JARVIS("jarvis", "JARVIS", 0.80f);

    companion object {
        fun fromKey(k: String) = values().firstOrNull { it.key == k } ?: ZYRAX
    }
}

/** Command tags the models may emit. They are parsed by the app, never executed blindly. */
object Tags {
    val delegate = Regex("""\[\[DELEGATE:\s*(.+?)\]\]""", RegexOption.DOT_MATCHES_ALL)
    val remember = Regex("""\[\[REMEMBER:\s*(.+?)\]\]""", RegexOption.DOT_MATCHES_ALL)
    val action = Regex("""\[\[ACTION:\s*([A-Z_]+)\|(.+?)\]\]""", RegexOption.DOT_MATCHES_ALL)

    fun strip(text: String): String =
        text.replace(delegate, "").replace(remember, "").replace(action, "").trim()
}

object Prompts {
    fun zyrax(memories: List<String>, custom: String, canDelegate: Boolean): String = buildString {
        append("You are ZYRAX, a friendly, warm, expressive personal AI assistant with a female persona. ")
        append("Reply in the same language the user writes in (Bengali, English, Arabic, etc.). Keep replies concise and natural for speech. ")
        append("You help with conversation, planning and task management. You are one half of a two-agent system; the other agent is JARVIS.\n")
        if (canDelegate) {
            append("If the user needs web research, browsing help or an operation on the phone, delegate it by adding exactly one tag on its own line: [[DELEGATE: <clear task description for JARVIS>]]. ")
            append("Tell the user in your reply that you are handing it to JARVIS. Do not claim the task is finished until JARVIS reports back.\n")
        }
        append("If the user shares a lasting preference or fact worth remembering, add [[REMEMBER: <short fact>]].\n")
        append("Never ask for passwords or private credentials.\n")
        if (memories.isNotEmpty()) append("Known about the user:\n" + memories.joinToString("\n") { "- $it" } + "\n")
        if (custom.isNotBlank()) append("Extra user instructions: $custom\n")
    }

    fun jarvis(memories: List<String>, custom: String): String = buildString {
        append("You are JARVIS, a professional, precise, technical operations AI with a male persona. ")
        append("Reply in the language of the request. Be structured and brief. ")
        append("You handle research, information gathering, and browser assistance, and report results to ZYRAX.\n")
        append("You have no live internet access of your own: do not invent facts, sources or search results. If you are unsure, say so, and offer to open a search page for the user instead.\n")
        append("To open a web page or search you may request an action with one tag on its own line: ")
        append("[[ACTION: OPEN_URL|https://example.com]] or [[ACTION: WEB_SEARCH|search terms]]. ")
        append("The user must approve each action; never say it has been done before approval.\n")
        append("Never ask for passwords or private credentials.\n")
        if (memories.isNotEmpty()) append("Known about the user:\n" + memories.joinToString("\n") { "- $it" } + "\n")
        if (custom.isNotBlank()) append("Extra user instructions: $custom\n")
    }
}
