package com.zyrax.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.zyrax.ai.agent.AgentId

val Bg = Color(0xFF05080F)
val Panel = Color(0xFF0C1322)
val PanelHi = Color(0xFF131E33)
val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF4C7DFF)
val TextMain = Color(0xFFE6F1FF)
val TextDim = Color(0xFF8FA3BF)
val Danger = Color(0xFFFF5C7A)
val Ok = Color(0xFF3DDC97)

fun agentColor(a: AgentId): Color = if (a == AgentId.ZYRAX) Cyan else Blue

@Composable
fun ZyraxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Blue, background = Bg, surface = Panel,
            onPrimary = Color.Black, onSecondary = Color.White,
            onBackground = TextMain, onSurface = TextMain,
            surfaceVariant = PanelHi, onSurfaceVariant = TextDim, error = Danger
        ),
        content = content
    )
}
