package com.zyrax.ai.ops

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

enum class ActionType(val description: String) {
    OPEN_URL("Open a web page in your browser"),
    WEB_SEARCH("Search the web in your browser")
}

data class PendingAction(val id: Long, val agent: String, val type: ActionType, val argument: String) {
    val summary: String get() = "${type.description}: $argument"
}

/**
 * Permission-controlled operations. Nothing here runs until the user taps Approve.
 * Only whitelisted action types exist; there is no shell, file or credential access.
 */
class OperationsManager(private val appContext: Context) {
    private val _pending = MutableStateFlow<List<PendingAction>>(emptyList())
    val pending: StateFlow<List<PendingAction>> = _pending
    private var nextId = 1L

    /** Returns null if the request is invalid or unsafe. */
    fun propose(agent: String, typeName: String, argument: String): PendingAction? {
        val type = runCatching { ActionType.valueOf(typeName.trim()) }.getOrNull() ?: return null
        val arg = argument.trim()
        if (arg.isEmpty() || arg.length > 500) return null
        if (type == ActionType.OPEN_URL && !isSafeUrl(arg)) return null
        val a = PendingAction(nextId++, agent, type, arg)
        _pending.update { it + a }
        return a
    }

    fun reject(id: Long) { _pending.update { list -> list.filterNot { it.id == id } } }

    /** Executes an approved action. Returns a human-readable result. */
    fun approve(id: Long): String {
        val a = _pending.value.firstOrNull { it.id == id } ?: return "Action no longer pending"
        _pending.update { list -> list.filterNot { it.id == id } }
        val uri = when (a.type) {
            ActionType.OPEN_URL -> Uri.parse(a.argument)
            ActionType.WEB_SEARCH -> Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.argument))
        }
        return try {
            appContext.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Executed: ${a.summary}"
        } catch (e: Exception) {
            "Failed: ${a.summary} (${e.message})"
        }
    }

    companion object {
        fun isSafeUrl(s: String): Boolean {
            val u = runCatching { Uri.parse(s) }.getOrNull() ?: return false
            return (u.scheme == "https" || u.scheme == "http") && !u.host.isNullOrBlank()
        }
    }
}
