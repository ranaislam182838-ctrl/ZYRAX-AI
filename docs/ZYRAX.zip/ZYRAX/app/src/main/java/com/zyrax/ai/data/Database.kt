package com.zyrax.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agent: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String,
    val fromAgent: String,
    val toAgent: String,
    val status: String, // PENDING, RUNNING, DONE, FAILED
    val result: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "activity_log")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agent: String,
    val action: String,
    val detail: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE agent = :agent ORDER BY id ASC")
    fun observe(agent: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE agent = :agent ORDER BY id DESC LIMIT :limit")
    suspend fun recent(agent: String, limit: Int): List<MessageEntity>

    @Insert suspend fun insert(m: MessageEntity): Long

    @Query("DELETE FROM messages WHERE agent = :agent")
    suspend fun clear(agent: String)

    @Query("DELETE FROM messages")
    suspend fun clearAll()
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun observe(): Flow<List<TaskEntity>>

    @Insert suspend fun insert(t: TaskEntity): Long
    @Update suspend fun update(t: TaskEntity)

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun get(id: Long): TaskEntity?

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM tasks")
    suspend fun clear()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY id DESC")
    fun observe(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY id ASC")
    suspend fun all(): List<MemoryEntity>

    @Insert suspend fun insert(m: MemoryEntity): Long

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM memories")
    suspend fun clear()
}

@Dao
interface LogDao {
    @Query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 200")
    fun observe(): Flow<List<LogEntity>>

    @Insert suspend fun insert(l: LogEntity): Long

    @Query("DELETE FROM activity_log")
    suspend fun clear()
}

@Database(
    entities = [MessageEntity::class, TaskEntity::class, MemoryEntity::class, LogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun tasks(): TaskDao
    abstract fun memories(): MemoryDao
    abstract fun logs(): LogDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "zyrax.db").build()
    }
}
