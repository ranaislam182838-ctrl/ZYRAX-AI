# Avatar assets

Import images in the app: **Settings → (agent) → Import image**. Images are copied to the app's private
storage (`files/avatars/zyrax.png`, `files/avatars/jarvis.png`) and downsized to max 1024 px.
Nothing is bundled, so no image is substituted for yours.

## What works with a single image
Idle breathing, head sway, glow ring, talking pulse, listening pulse, optional mouth overlay.

## What the built-in vector face does (no image imported)
Blinking, eye movement, expressions (neutral/happy/thinking/surprised), lip-sync mouth driven by speech state.

## What real facial animation on your photo needs
Blinking, eye movement and accurate lip-sync need the face split into layers (transparent PNG, same canvas size):
`base_face`, `eye_left_open/closed`, `eye_right_open/closed`, `pupil_left/right`, `mouth_closed/A/E/O/U`,
optional `brow_*`. Or a rigged model (Live2D / Spine / Rive). Supply these and the framework in
`ui/Avatar.kt` can be extended to composite them.

## Licensing
Stock images with Vecteezy / Dreamstime watermarks are not licensed for use in an app. Use licensed or
AI-generated images you own the rights to.
